
#include "stdafx.h"
#include <cmath>
#include "Matrix.h"
#include <stdexcept>
#include <iostream>

using namespace Matrix;

LABA2_API double Matrix::SinTaylor(double value, double accurancy)
{
	if (accurancy < 0.0 || accurancy >= 1)
	{
		//http://www.cplusplus.com/reference/exception/exception/
		throw std::out_of_range("Accurancy must be between 0 and 1!");
	}

	double term = value, sum = 0;

	for (int i = 1; fabs(term) > accurancy; i++)
	{
		sum += term;
		term = -term * value * value / (2 * i) / (2 * i + 1);
	}

	return sum;
}

LABA2_API double**  Matrix::AllocateMemory(int n)
{
	if (n <= 0 )
	{
		throw std::invalid_argument("Dimentions can not be less or equal zero!");
	}

	double** a = new double*[n];
	for (int i = 0; i < n; i++)
	{
		a[i] = new double[n];
	}

	return a;
}

LABA2_API void Matrix::FreeMemory(double** matrix, int rows)
{
	for (int i = 0; i < rows; ++i)
	{
		delete[] matrix[i];
	}
	delete[] matrix;
}

LABA2_API void Matrix::DisplayMatrix(double ** matrix, int  n)
{

	if (n <= 0)
	{
		throw std::out_of_range("Dimension of array must be more zero!");
	}

	if (matrix == nullptr)
	{
		throw std::invalid_argument("Argument is null!");
	}

	/*for (int i = 0; i < n; i++)
	{
		if ( *(matrix + i) == nullptr)
		{
			throw std::invalid_argument("Argument is null!");
		}
	}*/

	for (int i = 0; i < n; ++i)
	{

		for (int j = 0; j < n; ++j)
		{
			std::cout.width(6);
			std::cout << matrix[i][j];
		}
		std::cout << std::endl;
	}
}

LABA2_API void Matrix::InitMatrixTaylor(double ** matrix, int n, double accurancy)
{
	if (n <= 0)
	{
		throw std::out_of_range("Dimension of array must be more zero!");
	}

		if (matrix == nullptr)
		{
			throw std::invalid_argument("Argument is null!");
		}

		/*for (int i = 0; i < n; i++)
		{
			if (*(matrix + i) == nullptr)
			{
				throw std::invalid_argument("Argument is null!");
			}
		}*/

		double accurancy = 0.00001;

		for (int i = 0; i < n; i++)
		{
			for (int j = 0; j < n; j++)
			{
				if (i != 2 * j) matrix[i][j] = i;
				matrix[i][j] = ( SinTaylor(2 * i * j, accurancy) + SinTaylor(i , accurancy) ) / ((i - j - 4) ^ 3 + (i + j) ^ 2);
			}
		}
}

LABA2_API void Matrix::InitMatrixTable(double ** matrix, int n)
{
	if (n <= 0)
	{
		throw std::out_of_range("Dimension of array must be more zero!");
	}


	if (matrix == nullptr)
	{
		throw std::invalid_argument("Argument is null!");
	}

	/*for (int i = 0; i < n; i++)
	{
		if (*(matrix + i) == nullptr)
		{
			throw std::invalid_argument("Argument is null!");
		}
	}*/

	double accurancy = 0.00001;

	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			if (i != 2 * j) matrix[i][j] = i;
			matrix[i][j] = (sin(2 * i * j) + sin(i)) / ((i - j - 4) ^ 3 + (i + j) ^ 2);
		}
	}
}
LABA2_API double Matrix::CompareMatrix(double ** matrixTaylor, double ** matrixTable, int n)
{
	if (n <= 0)
	{
		throw std::out_of_range("Dimension of array must be more zero!");
	}

	double maxDiff = matrixTaylor[0][0] - matrixTable[0][0];

	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			if (fabs(matrixTaylor[i][j] - matrixTable[i][j]) > maxDiff) maxDiff = fabs(matrixTaylor[i][j] - matrixTable[i][j]);
		}
	}

	return maxDiff;
}

