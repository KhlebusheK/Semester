#pragma once

#ifdef LABA2_EXPORTS
#define LABA2_API __declspec(dllexport) 
#else
#define LABA2_API __declspec(dllimport) 
#endif

namespace Matrix
{
	LABA2_API double SinTaylor(double, double);
	LABA2_API double ** AllocateMemory(int n);
	LABA2_API void FreeMemory(double ** matrix, int n);
	LABA2_API void DisplayMatrix(double ** matrix, int n);
	LABA2_API void InitMatrixTaylor(double ** matrix, int n, double accurancy);
	LABA2_API void InitMatrixTable(double ** matrix, int n);
	LABA2_API double CompareMatrix(double ** matrixTaylor, double ** matrixTable, int n);
}