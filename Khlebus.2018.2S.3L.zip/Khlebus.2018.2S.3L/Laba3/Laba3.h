#pragma once

#ifdef LABA3_EXPORTS
#define LABA3_API __declspec(dllexport) 
#else
#define LABA3_API __declspec(dllimport) 
#endif

namespace Matrix
{
	LABA3_API double ** GenerateRandomMatrix(int n);
	LABA3_API void InitRandomMatrix(double ** array, int n);
	LABA3_API void FreeMemory(double ** matrix, int n);
	LABA3_API double ** AllocateMemory(int n);
	LABA3_API void FreeMemory(bool ** matrix, int n);
	LABA3_API void DisplayMatrix(bool ** matrix, int n);
	LABA3_API void DisplayMatrix(double ** array, int n);
	LABA3_API void Intersect(bool ** a, int n, int m, int size);
	LABA3_API double FindMax(double ** matrix, int i, int j, int n);
	LABA3_API double ** GenerateNewMatrix(double ** matrixA, int n);
}
