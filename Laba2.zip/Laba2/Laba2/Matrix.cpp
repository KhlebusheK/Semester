
#include "stdafx.h"
#include <cmath>
#include "Matrix.h"
#include <stdexcept>
#include <iostream>

using namespace Matrix;

LABA2_API double Matrix::SinTaylor(double value, double accurancy)
{
	if (accurancy < 0.0 || accurancy >= 1)
	{
		//http://www.cplusplus.com/reference/exception/exception/
		throw std::out_of_range("Accurancy must be between 0 and 1!");
	}

	double term = value, sum = 0;

	for (int i = 1; fabs(term) > accurancy; i++)
	{
		sum += term;
		term = -term * value * value / (2 * i) / (2 * i + 1);
	}

	return sum;
}

LABA2_API double ** Matrix::AllocateMemory(int n)
{
	if (n <= 0)
		throw std::out_of_range("Dimension must be more zero!");

	double ** matrix = new double *[n];

	for (int i = 0; i < n; i++)
	{
		*(matrix + i) = new double [n];
	}

	return matrix;

}

LABA2_API void Matrix::FreeMemory(double **matrix, int n)
{
	if (*matrix == nullptr)
	{
		throw std::invalid_argument("Argument is null!");
	}
	if (matrix == nullptr)
	{
		throw std::invalid_argument("Argument is null!");
	}

	for (int i = 0; i < n; i++)
	{
		delete[] * (matrix + i);
	}

}

LABA2_API void Matrix::DisplayMatrix(double ** matrix, int  n)
{

	if (n <= 0)
	{
		throw std::out_of_range("Dimension of array must be more zero!");
	}

	if (matrix == nullptr)
	{
		throw std::invalid_argument("Argument is null!");
	}

	for (int i = 0; i < n; i++)
	{
		if ( *(matrix + i) == nullptr)
		{
			throw std::invalid_argument("Argument is null!");
		}
	}

	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			std::cout << *(*(matrix + i) + j) << " ";
		}
		
	}
}

LABA2_API void Matrix::InitMatrixTaylor(double ** matrix, int n, double accurancy)
{
	if (n <= 0)
	{
		throw std::out_of_range("Dimension of array must be more zero!");
	}

		if (n <= 0)
		{
			throw std::out_of_range("Dimension of array must be more zero!");
		}

		if (matrix == nullptr)
		{
			throw std::invalid_argument("Argument is null!");
		}

		for (int i = 0; i < n; i++)
		{
			if (*(matrix + i) == nullptr)
			{
				throw std::invalid_argument("Argument is null!");
			}
		}

		int i = 0, j = 0;
	    double a = i, b = 2 * i * j;
		double pi = 3.14159265359;
		double A = (SinTaylor(b, accurancy) + SinTaylor(a, accurancy)) / ((i - j - 4) ^ 3 + (i + j) ^ 2);

		for (; i < n; i++)
		{
			for (; j < n; j++)
			{
				if (i > 2 * pi)
				{
					a = i - (double)i / 2 * pi;
					if (j) b = 2 * i * j - (double)(i * j) / pi;
				}

				if (i > pi && i < 2 * pi)
				{
					a = i - (double)i / pi;
					if (j) b = 2 * i * j - (double)(i * j) / pi;
				}
				if (i < pi)
				{
					if (i * j > pi) b = 2 * i * j - (double)(i * j) / pi;
					if (2 * i * j > pi && i * j < pi)  b = 2 * i * j - (double)(2 * i * j) / pi;
				}

				*(*(matrix + i) + j) = A;
			}
		}
}

LABA2_API void Matrix::InitMatrixTable(double ** matrix, int n)
{
	if (n <= 0)
	{
		throw std::out_of_range("Dimension of array must be more zero!");
	}

	if (n <= 0)
	{
		throw std::out_of_range("Dimension of array must be more zero!");
	}

	if (matrix == nullptr)
	{
		throw std::invalid_argument("Argument is null!");
	}

	for (int i = 0; i < n; i++)
	{
		if (*(matrix + i) == nullptr)
		{
			throw std::invalid_argument("Argument is null!");
		}
	}

	int i = 0, j = 0;
	double a = i, b = 2 * i * j;
	double pi = 3.14159265359;
	double A = (sin(b) + sin(a)) / ((i - j - 4) ^ 3 + (i + j) ^ 2);

	for (; i < n; i++)
	{
		for (; j < n; j++)
		{
			if (i > 2 * pi)
			{
				a = i - (double)i/ 2 * pi;
				if (j) b = 2 * i * j - (double)(i * j) / pi;
			}

			if (i > pi && i < 2 * pi)
			{
				a = i - (double)i / pi;
				if (j) b = 2 * i * j - (double)(i * j) / pi;
			}
			if (i < pi)
			{
				if (i * j > pi) b = 2 * i * j - ((double)(i * j) / pi);
				if (2 * i * j > pi && i * j < pi)  b = 2 * i * j - (double)(2 * i * j) / pi;
			}

			*(*(matrix + i) + j) = A;
		}
	}
}
LABA2_API void Matrix::CompareMatrix(double ** matrixTaylor, double ** matrixTable, int n)
{
	if (n <= 0)
	{
		throw std::out_of_range("Dimension of array must be more zero!");
	}

	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			
		}
	}
}

