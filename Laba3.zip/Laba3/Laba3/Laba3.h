#pragma once

#ifdef LABA3_EXPORTS
#define LABA3_API __declspec(dllexport) 
#else
#define LABA3_API __declspec(dllimport) 
#endif

namespace Matrix
{
	LABA3_API void FreeHeap(int ** a, int n);
	LABA3_API void InitMatrix(int ** array, int n);
	LABA3_API int ** AllocateMemory(int n);
	LABA3_API void DisplayMatrix(int ** array, int n);
	LABA3_API void NewMatrix(int ** array, int ** B, int n);
	LABA3_API int Max(int ** matrix, int n);
	LABA3_API int Sort(int ** matrix, int n);
}
